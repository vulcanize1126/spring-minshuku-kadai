const stripe = Stripe('pk_test_51QnitlLOKI89sl5dqX8q27puVOYBIGRvwnYsBBO0iNV2oOAeRssnO3ubsR8lOzhK0K5m1VJARxoS5b3RMFYMO8AW00c6eDGs66');
const paymentButton = document.querySelector('#paymentButton');

paymentButton.addEventListener('click', () => {
 stripe.redirectToCheckout({
   sessionId: sessionId
 })
});